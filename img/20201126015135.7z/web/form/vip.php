<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>尊爵貴賓室</h1>
尊爵的 <?=$_GET['name'];?> 你好，歡迎你的降臨
</body>
</html>