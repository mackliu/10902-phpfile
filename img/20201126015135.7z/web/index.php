<?php

$hello="hello taiwan";
$today=date("Y-m-d");

echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";

$hello="hello today";
$today=date("Y-m-d H:i:s");

echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";

$hello="要訂便當囉";
$today=date("H:i:s");


echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";
echo $hello . " , " . $today . "<br>";

?>