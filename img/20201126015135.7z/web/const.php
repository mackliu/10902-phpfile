<?php

define("PI",3.1415);

echo PI*10;
echo "<br>";


define("PI",0.15151515);
echo PI*10;
?>